﻿using dotNetSeleniumTestingFramework.Helpers;
using Newtonsoft.Json;
using Reqnroll;
using System;
using System.IO;

namespace dotNetSeleniumTestingFramework.SetupTeardown
{
    [Binding]
    public class BeforeScenario
    {
        [BeforeScenario(Order = 1)]
        public static void SetUp()
        {
            string settingsJson = File.ReadAllText(
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TestSettings.json"));
            TestSettings settings = JsonConvert.DeserializeObject<TestSettings>(settingsJson);
            Driver.Initialize(settings);
        }
    }
}
