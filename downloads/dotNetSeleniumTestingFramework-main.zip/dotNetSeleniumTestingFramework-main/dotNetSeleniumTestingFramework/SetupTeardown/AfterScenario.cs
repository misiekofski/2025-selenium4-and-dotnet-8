﻿using dotNetSeleniumTestingFramework.Helpers;
using Reqnroll;

namespace dotNetSeleniumTestingFramework.SetupTeardown
{
    [Binding]
    public class AfterScenario
    {
        [AfterScenario(Order = 1000)]
        public static void TearDown() => Driver.Instance.Quit();
    }
}
