﻿namespace dotNetSeleniumTestingFramework.Helpers.Enums
{
    public enum BrowserType
    {
        Chrome,
        Firefox,
        Edge
    }
}
