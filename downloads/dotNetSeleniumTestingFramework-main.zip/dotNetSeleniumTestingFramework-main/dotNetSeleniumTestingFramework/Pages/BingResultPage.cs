﻿using System;
using System.Collections.Generic;
using System.Text;

namespace dotNetSeleniumTestingFramework.Pages
{
    public class BingResultPage
    {
        internal List<string> GetFirstThreeResults()
        {
            return new List<string>();
        }
    }
}
